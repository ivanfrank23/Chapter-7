let currentPage = 1;
const totalPages = 4;

function updateButtons() {
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
}

function nextPage() {
    if (currentPage < totalPages) {
        const page = document.querySelector(`[data-page="${currentPage}"]`);
        page.classList.add('flipped');
        currentPage++;
        updateButtons();
    }
}

function previousPage() {
    if (currentPage > 1) {
        currentPage--;
        const page = document.querySelector(`[data-page="${currentPage}"]`);
        page.classList.remove('flipped');
        updateButtons();
    }
}

updateButtons();